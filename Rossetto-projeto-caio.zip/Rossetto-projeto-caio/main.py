from login import faz_login

usuario = faz_login