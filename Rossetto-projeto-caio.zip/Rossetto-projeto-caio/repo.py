from hashlib import sha256
from hashlib import sha256

def lista_usuarios():
    from login import usuario
    return [
        usuario(login='Rossetto', senha=sha256("1892009vrC.").digest())
    ]