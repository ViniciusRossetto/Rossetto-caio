from dataclasses import dataclass
from getpass import getpass
from hashlib import sha256

from repo import lista_usuarios


@dataclass
class usuario:
    login: str
    senha: str

def pedir_login() -> usuario:
    login = input('Digite o seu login')
    senha = getpass('Digite a sua senha')
    senha = sha256(senha.encode()).digest()
    return usuario(login, senha)

def faz_login():
    usuario = lista_usuarios()
    usuario = pedir_login()
    for usuario_salvo in usuario:
        if usuario_salvo.login == usuario.login and usuario_salvo == usuario_salvo:
            return usuario_salvo
    print('usuario não encontrado')
    return None

